/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.br.senac.controller;

import com.br.senac.DAO.produtos.editarProduto;
import com.br.senac.DAO.produtos.inclusaoProduto;
import com.br.senac.model.listarProdutos;
import com.br.senac.model.produtos;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author paulo.bezerra
 */
@WebServlet(name = "editar", urlPatterns = {"/editar"})
public class editar extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        PrintWriter out = response.getWriter();

        HttpSession sessao = request.getSession(true);

        int id = Integer.valueOf(request.getParameter("id"));
        String nome = request.getParameter("nome");
        String descricao = request.getParameter("descricao");
        double preco_compra = Double.valueOf(request.getParameter("preco_compra").replace(".", "").replace(",", "."));
        double preco_venda = Double.valueOf(request.getParameter("preco_venda").replace(".", "").replace(",", "."));
        int quantidade = Integer.valueOf(request.getParameter("quantidade"));
        boolean disponivel = Boolean.valueOf(request.getParameter("disponivel"));
        String dt_cadastro = "";


        produtos produtos = new produtos(id, nome, descricao, preco_compra,
                preco_venda, quantidade, disponivel, dt_cadastro);

        editarProduto editar = new editarProduto();
        boolean editado = editar.editar(produtos);

        if (editado == true) {
            listarProdutos listar = new listarProdutos();

            ResultSet produtoslist = listar.listar();

            request.setAttribute("produtos", produtoslist);
            request.getRequestDispatcher("index.jsp").forward(request, response);

        }

    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
