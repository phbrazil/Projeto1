/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.br.senac.DAO.produtos;

import com.br.senac.DAO.conexao.conexaoDAO;
import com.br.senac.model.produtos;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author paulo.bezerra
 */
public class inclusaoProduto {

    public boolean inclusao(produtos produtos) {

        boolean success = false;

        conexaoDAO bancoconexao = new conexaoDAO();

        try {

            Connection conexao = bancoconexao.getConnection();

            String query = ("INSERT INTO produto (nome,descricao, preco_compra,"
                    + "preco_venda, quantidade,disponivel, dt_cadastro)"
                    + " VALUES (?,?,?,?,?,?,now())");

            PreparedStatement preparedStmt = conexao.prepareStatement(query);
            preparedStmt.setString(1, produtos.getNome());
            preparedStmt.setString(2, produtos.getDescricao());
            preparedStmt.setDouble(3, produtos.getPreco_compra());
            preparedStmt.setDouble(4, produtos.getPreco_venda());
            preparedStmt.setInt(5, produtos.getQuantidade());
            preparedStmt.setBoolean(6, produtos.isDisponivel());
            
            preparedStmt.execute();

            success = true;

            produtos = null;

            conexao.close();

        } catch (Exception e) {

            System.out.println("Erro gravar produto " + e.getMessage());

        }
        return success;
    }

}
