/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.br.senac.controller;

import com.br.senac.DAO.produtos.consulta;
import com.br.senac.model.produtos;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author paulo.bezerra
 */
@WebServlet(name = "editarConsulta", urlPatterns = {"/editarConsulta"})
public class editarConsulta extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        

        request.setCharacterEncoding("UTF-8");

        PrintWriter out = response.getWriter();

        HttpSession sessao = request.getSession(true);

        int id = Integer.valueOf(request.getParameter("id"));
        
        System.out.println("id aqui ta "+id);

        consulta consulta = new consulta();

        produtos produto = new produtos(0, null, null, 0, 0, 0, true, null);
        produto = consulta.produtos(id);
        

        request.setAttribute("produto", produto);
        request.getRequestDispatcher("editar.jsp").forward(request, response);

    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
